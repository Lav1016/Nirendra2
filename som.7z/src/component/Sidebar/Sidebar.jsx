import "./Sidebar.css";
import React from "react";

// import {LineStyle} from "@material-ui/icons";




export default function sidebar() {
    return (
        <>
            <div className="Sidebar">
                <div className="SidebarWrapper">
                    <div className="SidebarManu">
                        <h3 className="SidebarTitle">dashboard</h3>
                        <ul className="SidebarList">
                            <li className="SidebarListItem">
                                {/* <LineStyle className="SidebarIcons" /> */}
                                Home
                            </li>

                        </ul>
                    </div>
                </div>

            </div>
        </>

        // {/* //                 <div className="SidebarManu">
        // //                     <h3 className="SidebarTitle">quick Manu</h3>
        // //                     <ul className="SidebarList">
        // //                         <li className="SidebarListItem">
        // //                         <Linestyle className="SidebarIcon"/>
        // //                         User
        // //                         </li>
        // //                     <li className="sideListItem">
        // //                         <Timeline className="SidebarIcon"/>
        // //                         production
        // //            </li>
        // //            <li className="sidebarListItem">
        // //                <TrendingUp className="SidebarIcon"/>
        // //                Transactions
        // //            </li>
        // //            <li className="sidebarListItem">
        // //                <TrendingUp className="SidebarIcon"/>
        // //                Report
        // //                </li>
        // //                     </ul>
        // //                 </div>


        // //                 <div className="SidebarManu">
        // //                     <h3 className="SidebarTitle">Notification</h3>
        // //                     <ul className="SidebarList">
        // //                         <li className="SidebarListItem">
        // //                         <Linestyle className="SidebarIcon"/>
        // //                         Mail
        // //                         </li>
        // //                     <li className="sideListItem">
        // //                         <Timeline className="SidebarIcon"/>
        // //                         feedback
        // //            </li>
        // //            <li className="sidebarListItem">
        // //                <TrendingUp className="SidebarIcon"/>
        // //                Messages
        // //            </li>
        // //                     </ul>
        // //                 </div>

        // //                 <div className="SidebarManu">
        // //                     <h3 className="SidebarTitle">Staff</h3>
        // //                     <ul className="SidebarList">
        // //                         <li className="SidebarListItem">
        // //                         <Linestyle className="SidebarIcon"/>
        // //                         Manage
        // //                         </li>
        // //                     <li className="sideListItem">
        // //                         <Timeline className="SidebarIcon"/>
        // //                         Analytics
        // //            </li>
        // //            <li className="sidebarListItem">
        // //                <TrendingUp className="SidebarIcon"/>
        // //                Report
        // //            </li>
        // //                     </ul>
        // //                 </div> */}

        // //             </div>
        // </div>
        // </div>



    )
}
