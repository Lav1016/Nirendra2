import React from "react";
// import Sidebar from './component/Sidebar/Sidebar';
// import Topbar from "./component/Topbar/Topbar";
import "./App.css";
const App = () => {
  return (
  <div>
    {/* <Topbar/>
  <div className="container_up">
    <Sidebar/>
    <div className="other_up">other pages </div>
  </div> */}
  <h3>Home component</h3>
    </div>
    )
}

export default App;
